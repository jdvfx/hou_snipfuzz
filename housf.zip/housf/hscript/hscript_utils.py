
class Hscript:
    def __init__(self):
        pass

    def get_hscript(self):
        print("get hscript")

    def solversops_to_subnets(self):
        print("solversops_to_subnets")

    def solversop_to_subnet(self):
        print("solversop_to_subnet")

    def subnet_to_solversop(self):
        print("subnet_to_solversop")

    def subnets_to_solversops(self):
        print("subnets_to_solversops")
