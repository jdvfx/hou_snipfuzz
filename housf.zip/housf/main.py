# from hscript.hscript_utils import Hscript
# from hscript import hscript_utils as h
#
# hs = h.Hscript()
# hs.get_hscript()

from hscript import Hscript

h = Hscript()
print(h)


"""
MVC
MVVM
MVP
state
"""


